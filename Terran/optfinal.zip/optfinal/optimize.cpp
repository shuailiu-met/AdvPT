#include "Race.h"
#include "Terran.h"
#include "DataAcc.h"
#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <fstream>
#include <cstdlib>
#include <ctime>
//#include "algorithm"

#define START_COUNT 10000

using namespace std;

struct optimize{
    int time;
    std::vector<std::string> buildlist;
    std::vector<std::string> validlist;
    int count;
    int current_value;
};

int main(int argc, char* argv[]){

    // seed the random number creation with an non-deterministic seed
        DataAcc data("/Users/songjingwei/Desktop/Master course/advpt/Project/Materials Part 2_ Forward Simulation/unit_db.csv", "/Users/songjingwei/Desktop/Master course/advpt/Project/Materials Part 2_ Forward Simulation/parameters.csv");
        // get racename
        string race_name("Terr");
    // create random buildorders lists
    struct optimize arr[START_COUNT];
    std::vector<int> buildtime;
    std::vector<std::string> vbuildlist;
    int number = 1;
    bool push = false;
    
    Race *simRace = nullptr;
    // get the given race
    if(!race_name.compare("Terr")){
        if (push) {
            int j = 0;
            for(size_t i = 0; i < START_COUNT; i++){
                arr[i].buildlist = data.getRandomBuildorder("Terr", "Battlecruiser",number);
              }
            for(size_t i = 0; i < START_COUNT; i++){
                   simRace = new Terran(&data, arr[i].buildlist, false);
                   while((simRace->advanceOneTimeStep()));
                   cout << "Valid: " << simRace->buildlistValid() << ", time: " << simRace->getSimulationTime() << "\n";
            if (simRace->buildlistValid() == 0) {
                buildtime.push_back(simRace->getSimulationTime());
                arr[j].validlist = arr[i].buildlist;
                j++;
            }
              }
                 }
        else{
            int j =0;
              for(size_t i = 0; i < START_COUNT; i++){
                  arr[i].buildlist = data.getRandomBuildorderrush("Terr", "Marine");
                   }
              for(size_t i = 0; i < START_COUNT; i++){
                   simRace = new Terran(&data, arr[i].buildlist, false);
                   while((simRace->advanceOneTimeStep()));
                   cout << "Valid: " << simRace->buildlistValid() << ", time: " << simRace->getSimulationTime() << "\n";
            
                    if (simRace->buildlistValid() == 0) {
                        buildtime.push_back(simRace->getSimulationTime());
                        arr[j].validlist = arr[i].buildlist;
                        j++;
                       }
//                  if (simRace->buildlistValid() != 0 ) {
//                      delete.arr[i].buildlist;
//                  }
                }
               
           }
         vector<int>::iterator q = min_element(buildtime.begin(), buildtime.end());
         std::cout<< *q <<std::endl;
         auto a = std::distance(std::begin(buildtime),q);
         simRace = new Terran(&data, arr[a].validlist, true);
                           while((simRace->advanceOneTimeStep()));

    }

    return 0;
}
