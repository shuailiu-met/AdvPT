#!/bin/bash

./simulate $1 $2
