#include "Race.h"
#include "General/DataAcc.h"
#include "Zerg/Zerg.h"
#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <fstream>


#define START_COUNT 10000

using namespace std;


struct optimize{
    int time;
    std::vector<std::string> buildlist;
    int count;
    int current_value;
    bool valid;
    bool queenrush;
};


int main(int argc, char* argv[])
{
    DataAcc *data;
    data = new DataAcc("res/unit_db.csv", "res/parameters.csv");
    //std::vector<std::string>answer0 = data->getRandomBuildorder("Zerg","Ultralisk","push",3);
    //std::vector<std::string>answer1 = data->getRandomBuildorder("Zerg","Ultralisk","push",3);

    Race *simRace = nullptr;
    Race *bestList = nullptr;
    std::vector<std::string> best_list;
    std::vector<std::string> opt_list;
    int best_time = 10000;
    int best_number = 0;
    struct optimize arr[START_COUNT];
    string strategy(argv[1]);
    string target(argv[2]);
    int param = stoi(argv[3]);

    if(strategy=="push"){
    for(size_t i = 0; i < START_COUNT; i++){
        arr[i].buildlist = data->getRandomBuildorder("Zerg",target,strategy,param);
    }


     for(size_t i = 0; i < START_COUNT; i++){
        simRace = new Zerg(data, arr[i].buildlist, false);
        while((simRace->advanceOneTimeStep()));
        //cout << "Valid: " << simRace->buildlistValid() << ", time: " << simRace->getSimulationTime() << "\n";
        if((simRace->buildlistValid()==true)&&(simRace->getSimulationTime()<best_time))
        {
            best_list = arr[i].buildlist;
            best_time = simRace->getSimulationTime();
        }
    }
    bestList = new Zerg(data, best_list,true);
    while((bestList->advanceOneTimeStep()));
    }



    if(strategy=="rush"){
     int length;
     for(size_t i = 0; i < START_COUNT; i++){
            int build_time = data->getAttributeValue(target, DataAcc::build_time);
            int min = ((param / build_time) / 2);
            int max = ((param / build_time) * 2);
            length = rand() % (max-min) + min;
            arr[i].buildlist = data->getRandomBuildorder("Zerg", target, strategy, length);
            arr[i].count = 0;
            arr[i].queenrush = false;
            for(auto it = arr[i].buildlist.begin();it!=arr[i].buildlist.end();it++)
            {if(*it=="Queen"){arr[i].queenrush = true;}}
     }
            /*for(auto it = arr[50].buildlist.begin();it!=arr[50].buildlist.end();it++)
            {std::cout <<*it << std::endl;}*/
     for(size_t i = 0; i < START_COUNT; i++){
        if(arr[i].queenrush==false){
        simRace = new Zerg(data, arr[i].buildlist, false);
        while((simRace->advanceOneTimeStep()));
        //cout << "Valid: " << simRace->buildlistValid() << ", time: " << simRace->getSimulationTime() << "\n";
        if((simRace->buildlistValid()==true)&&(simRace->getSimulationTime()<param))
        {
            for(auto it = arr[i].buildlist.begin();it!=arr[i].buildlist.end();it++){
            if(*it==target){arr[i].count++;}   
            }
            if(arr[i].count>best_number)
            {best_number = arr[i].count;
            best_list = arr[i].buildlist;}
        }
        }
    }
    /*std::cout << arr[50].queenrush << std::endl;
            for(auto it = arr[50].buildlist.begin();it!=arr[50].buildlist.end();it++)
            {cout << *it << endl;}

               for(auto it = best_list.begin();it!=best_list.end();it++)
            {cout << *it << endl;}*/
        /*best_list.push_back("SpawningPool");
        best_list.push_back("Queen");
        best_list.push_back("Overlord");
        best_list.push_back("Zergling");
        best_list.push_back("Zergling");
        best_list.push_back("Zergling");
        best_list.push_back("Zergling");*/
         bestList = new Zerg(data, best_list,true);
    while((bestList->advanceOneTimeStep()));
     //{cout << data->getAttributeValue(*it,DataAcc::supply,false)<<endl;}
     

    }


    return 0;
}

