#!/bin/bash
./optimize $1 $2 $3
